/**
 * Pianetto Transportes - Sistema de Armazenamento com Fallback
 * Tenta usar a API do servidor (tables/ordens).
 * Se não tiver conexão, usa o localStorage como fallback.
 */

const DB_TABLE = 'ordens';
const LOCAL_KEY = 'pianetto_ordens';
const LOCAL_COUNTER_KEY = 'pianetto_oc_counter';
const LOCAL_PEDIDO_COUNTER_KEY = 'pianetto_pedido_counter';

// ─────────────────────────────────────────────
// Detecta se a API está disponível
// ─────────────────────────────────────────────
async function isApiAvailable() {
  try {
    const res = await fetch(`tables/${DB_TABLE}?limit=1`, { method: 'GET' });
    return res.ok;
  } catch {
    return false;
  }
}

// ─────────────────────────────────────────────
// Gera número de O.C. sequencial
// ─────────────────────────────────────────────
function gerarNumeroOC() {
  const ano = new Date().getFullYear();
  let contador = parseInt(localStorage.getItem(LOCAL_COUNTER_KEY) || '0') + 1;
  localStorage.setItem(LOCAL_COUNTER_KEY, contador);
  return `OC-${ano}-${String(contador).padStart(4, '0')}`;
}

// ─────────────────────────────────────────────
// Gera número de Pedido sequencial
// ─────────────────────────────────────────────
function gerarNumeroPedido() {
  const ano = new Date().getFullYear();
  let contador = parseInt(localStorage.getItem(LOCAL_PEDIDO_COUNTER_KEY) || '0') + 1;
  localStorage.setItem(LOCAL_PEDIDO_COUNTER_KEY, contador);
  return `PEDIDO-${ano}-${String(contador).padStart(4, '0')}`;
}

// ─────────────────────────────────────────────
// LocalStorage CRUD
// ─────────────────────────────────────────────
function localGetAll() {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_KEY) || '[]');
  } catch {
    return [];
  }
}

function localSave(ordens) {
  localStorage.setItem(LOCAL_KEY, JSON.stringify(ordens));
}

function localCreate(dados) {
  const ordens = localGetAll();
  const novo = {
    ...dados,
    id: 'local_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
    created_at: Date.now(),
    updated_at: Date.now(),
    _local: true
  };
  ordens.unshift(novo);
  localSave(ordens);
  return novo;
}

function localUpdate(id, dados) {
  const ordens = localGetAll();
  const idx = ordens.findIndex(o => o.id === id);
  if (idx === -1) return null;
  ordens[idx] = { ...ordens[idx], ...dados, updated_at: Date.now(), _local: true };
  localSave(ordens);
  return ordens[idx];
}

function localDelete(id) {
  const ordens = localGetAll().filter(o => o.id !== id);
  localSave(ordens);
}

function localGetById(id) {
  return localGetAll().find(o => o.id === id) || null;
}

// ─────────────────────────────────────────────
// API CRUD
// ─────────────────────────────────────────────
async function apiCreate(dados) {
  const res = await fetch(`tables/${DB_TABLE}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  });
  if (!res.ok) throw new Error('Falha ao criar no servidor');
  return await res.json();
}

async function apiGetAll(page = 1, limit = 200, filters = {}) {
  let url = `tables/${DB_TABLE}?page=${page}&limit=${limit}&sort=created_at`;
  if (filters.search) url += `&search=${encodeURIComponent(filters.search)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Falha ao buscar do servidor');
  return await res.json();
}

async function apiUpdate(id, dados) {
  const res = await fetch(`tables/${DB_TABLE}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  });
  if (!res.ok) throw new Error('Falha ao atualizar no servidor');
  return await res.json();
}

async function apiDelete(id) {
  const res = await fetch(`tables/${DB_TABLE}/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Falha ao deletar no servidor');
}

async function apiGetById(id) {
  const res = await fetch(`tables/${DB_TABLE}/${id}`);
  if (!res.ok) throw new Error('Falha ao buscar do servidor');
  return await res.json();
}

// ─────────────────────────────────────────────
// Interface Unificada com Fallback
// ─────────────────────────────────────────────
const Storage = {
  _apiDisponivel: null,

  async verificar() {
    this._apiDisponivel = await isApiAvailable();
    this._atualizarBanner();
    return this._apiDisponivel;
  },

  _atualizarBanner() {
    const banner = document.getElementById('storage-status-banner');
    if (!banner) return;
    if (this._apiDisponivel) {
      banner.innerHTML = `<span class="status-dot online"></span> <strong>Modo Online</strong> — dados salvos no servidor (compartilhados com toda a equipe)`;
      banner.className = 'storage-banner online';
    } else {
      banner.innerHTML = `<span class="status-dot offline"></span> <strong>Modo Offline</strong> — dados salvos localmente neste navegador. Ao reconectar, publique novamente para sincronizar.`;
      banner.className = 'storage-banner offline';
    }
    banner.style.display = 'flex';
  },

  async salvar(dados) {
    if (this._apiDisponivel === null) await this.verificar();
    if (this._apiDisponivel) {
      try {
        return await apiCreate(dados);
      } catch {
        this._apiDisponivel = false;
        this._atualizarBanner();
        return localCreate(dados);
      }
    }
    return localCreate(dados);
  },

  async listar(filtros = {}) {
    if (this._apiDisponivel === null) await this.verificar();
    if (this._apiDisponivel) {
      try {
        const res = await apiGetAll(1, 500, filtros);
        return res.data || [];
      } catch {
        this._apiDisponivel = false;
        this._atualizarBanner();
        return localGetAll();
      }
    }
    return localGetAll();
  },

  async buscarPorId(id) {
    if (this._apiDisponivel === null) await this.verificar();
    if (this._apiDisponivel) {
      try {
        return await apiGetById(id);
      } catch {
        return localGetById(id);
      }
    }
    return localGetById(id);
  },

  async atualizar(id, dados) {
    if (this._apiDisponivel === null) await this.verificar();
    if (this._apiDisponivel) {
      try {
        return await apiUpdate(id, dados);
      } catch {
        return localUpdate(id, dados);
      }
    }
    return localUpdate(id, dados);
  },

  async deletar(id) {
    if (this._apiDisponivel === null) await this.verificar();
    if (this._apiDisponivel) {
      try {
        await apiDelete(id);
        return;
      } catch {
        localDelete(id);
        return;
      }
    }
    localDelete(id);
  },

  // Tenta sincronizar dados locais com o servidor quando reconectar
  async sincronizar() {
    const online = await isApiAvailable();
    if (!online) return { sincronizado: 0, erro: 'Servidor ainda indisponível' };

    const locais = localGetAll().filter(o => o._local);
    let sincronizado = 0;
    for (const ordem of locais) {
      try {
        const { id, _local, created_at, updated_at, ...dados } = ordem;
        const nova = await apiCreate(dados);
        localDelete(id);
        sincronizado++;
      } catch (e) {
        console.warn('Erro ao sincronizar ordem', ordem.id, e);
      }
    }
    this._apiDisponivel = true;
    this._atualizarBanner();
    return { sincronizado };
  }
};
