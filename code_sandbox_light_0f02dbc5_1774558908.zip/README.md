# Pianetto Transportes — Sistema de Ordens de Coleta

Sistema web completo para criação, gestão e impressão de ordens de coleta da **Pianetto Transportes e Logística**.

---

## ✅ Funcionalidades implementadas

- **Formulário de nova ordem** com todos os campos da ordem original
- **Campo PEDIDO** editável (numeração sugerida automaticamente)
- **Campo O.C** com numeração sequencial automática e somente leitura
- **Data de emissão** preenchida automaticamente com a data atual
- **Cálculo automático** de Total Frete e Saldo a Pagar
- **Salvar no histórico** — persiste no banco de dados do servidor
- **🔁 Fallback local** — se o servidor não estiver disponível, os dados são salvos no `localStorage` do navegador
- **Banner de status** indicando se os dados estão sendo salvos online ou localmente
- **Botão sincronizar** — quando o servidor voltar, sincroniza os dados locais
- **Gerar PDF / Imprimir** — layout A4 pronto para impressão
- **Painel de histórico** com filtros por data, status e busca textual
- **Cards de resumo** por status (Pendente, Em Transporte, Entregue, Cancelada)
- **Tabela paginada** com ordenação por coluna
- **Modal de detalhes** com alteração de status
- **Botão Duplicar ordem** — gera nova O.C automática, bloqueia campos sensíveis
- **Botão PDF no histórico** — reimprimir qualquer ordem
- **Exportar CSV** dos registros filtrados
- **Logo da Pianetto** no cabeçalho, histórico, rodapé e impressão

---

## 📁 Estrutura de Arquivos

```
index.html          → Formulário de nova ordem
historico.html      → Painel de histórico com filtros
print.html          → Página de impressão/PDF da ordem
js/storage.js       → Lógica de armazenamento com fallback local
css/style.css       → Estilos globais
images/logo.png     → Logo da Pianetto
README.md
```

---

## 🔗 Páginas do sistema

| Página | Caminho | Descrição |
|---|---|---|
| Nova Ordem | `/index.html` | Criar nova ordem de coleta |
| Histórico | `/historico.html` | Visualizar e filtrar todas as ordens |
| Impressão | `/print.html?id={ID}` | Imprimir ou salvar PDF de uma ordem |
| Duplicar | `/index.html?duplicar={ID}` | Duplicar ordem existente |
| Editar | `/index.html?editar={ID}` | Editar ordem existente |

---

## 💾 Armazenamento com Fallback

### Modo Online (servidor disponível)
- Dados salvos via API REST: `tables/ordens`
- Acessível por toda a equipe em qualquer dispositivo

### Modo Offline (fallback local)
- Dados salvos no `localStorage` do navegador
- Banner amarelo avisa que os dados estão locais
- Botão **Sincronizar** envia os dados locais para o servidor quando a conexão voltar

### Indicadores visuais
- 🟢 **Verde** — Modo Online: dados salvos no servidor
- 🟡 **Amarelo** — Modo Offline: dados salvos localmente no navegador
- Badge `local` na tabela do histórico para identificar ordens ainda não sincronizadas

---

## 🗄️ Modelo de Dados (tabela `ordens`)

| Campo | Tipo | Descrição |
|---|---|---|
| numero_pedido | text | Número do pedido (editável) |
| numero_oc | text | O.C sequencial automática |
| data_emissao | text | Data de emissão (YYYY-MM-DD) |
| data_agendamento | text | Data de agendamento |
| status | text | Pendente / Em Transporte / Entregue / Cancelada |
| remetente | text | Nome do remetente |
| cidade_origem | text | Cidade de origem |
| recebedor | text | Nome do recebedor |
| destino | text | Cidade de destino |
| peso_bruto | text | Peso em KG |
| mercadoria | text | Tipo de mercadoria |
| terminal | text | Terminal |
| mod_veiculo | text | Modelo do veículo |
| placa_cav | text | Placa do cavalo |
| placa_car1/dolly/car3 | text | Placas das carretas |
| uf | text | UF |
| motorista | text | Nome do motorista |
| celular | text | Celular |
| cpf/rg/cnh | text | Documentos do motorista |
| local_coleta | text | Local de coleta |
| observacoes | text | Observações |
| valor_ton/total_frete/pedagio/adiantamento/saldo_pagar | text | Valores financeiros |

---

## 🚀 Próximos passos recomendados

- [ ] Autenticação de usuários (login/senha por motorista ou analista)
- [ ] Notificação por WhatsApp ao criar/atualizar ordem
- [ ] Dashboard com gráficos de ordens por período
- [ ] Filtro por motorista/veículo no histórico
- [ ] Integração com API de CEP para autopreenchimento de endereços
- [ ] Assinatura digital no formulário
